package repository;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.CommentController;
import orm.DatabaseBuilder;

public class CommentDAOImpl implements CommentDAO {
	private static Logger Log = LoggerFactory.getLogger(CommentController.class);
	private SqlSession sql;
	private final String NS ="commentMapper.";
	
	public CommentDAOImpl() {
		new DatabaseBuilder();
		sql = DatabaseBuilder.getFactory().openSession();
	}
}
