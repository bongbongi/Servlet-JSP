package repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.boardVO;
import domain.pagingVO;
import orm.DatabaseBuilder;

public class BoardDAOImpl implements BoardDAO {
	private static final Logger Log = LoggerFactory.getLogger(MemberDAOImpl.class);
	private SqlSession sql;
	private final String NS = "boardMapper.";
	
	public BoardDAOImpl() {
		new DatabaseBuilder();
		sql = DatabaseBuilder.getFactory().openSession();
	}

	@Override
	public int insert(boardVO bvo) {
		Log.info("insert check 3");
		int isOk = sql.insert(NS+"insert",bvo); ;
		if(isOk>0) {
			sql.commit();
		}			
		return isOk;
	}

	@Override
	public List<boardVO> list() {
		Log.info("list check 3");
		return sql.selectList(NS+"list");
	}

	@Override
	public boardVO detail(int bno) {
		Log.info("detail check 3");
		return sql.selectOne(NS+"detail",bno);
	}

	@Override
	public int update(boardVO bvo) {
		Log.info("update check 3");
		int isOk = sql.update(NS+"update",bvo); ;
		if(isOk>0) {
			sql.commit();
		}		
		return isOk;
	}

	@Override
	public int delete(int bno) {
		Log.info("delete check 3");
		int isOk = sql.delete(NS+"delete",bno); ;
		if(isOk>0) {
			sql.commit();
		}
		return isOk;
	}

	@Override
	public int updateCount(int bno) {
		Log.info("updateCount check 3");
		int isOk = sql.update(NS+"updateCount",bno); ;
		if(isOk>0) {
			sql.commit();
		}		
		return isOk;
	}

	@Override
	public int selectCount() {
		// TODO Auto-generated method stub
		return sql.selectOne(NS+"cnt");
	}

	@Override
	public List<boardVO> selectList(pagingVO pgvo) {
		// TODO Auto-generated method stub
		return sql.selectList(NS+"pagingList",pgvo);
	}
	
	
}
