package repository;

public interface CommentDAO {

}
