package service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.CommentController;
import repository.CommentDAO;
import repository.CommentDAOImpl;

public class CommentServiceImpl implements CommentService {
	private static Logger Log = LoggerFactory.getLogger(CommentController.class);
	private CommentDAO cdao;
	//생성자
	public CommentServiceImpl() {
		cdao = new CommentDAOImpl();
	}
}
