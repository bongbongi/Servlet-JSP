package service;

import java.util.List;

import domain.boardVO;
import domain.pagingVO;

public interface BoardService {

	int insert(boardVO bvo);

	List<boardVO> getList();

	boardVO getDetail(int bno);

	int update(boardVO bvo);

	int delete(int bno);

	int updateCount(int bno);

	int getPageCnt();

	List<boardVO> getListPage(pagingVO pgvo);



	
}
