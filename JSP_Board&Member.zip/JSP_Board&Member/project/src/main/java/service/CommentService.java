package service;

public interface CommentService {

}
