package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.boardVO;
import domain.pagingVO;
import handler.PagingHandler;
import service.BoardService;
import service.BoardServiceImpl;
import service.MemberService;

@WebServlet("/brd/*")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger Log = LoggerFactory.getLogger(MemberController.class);
	private BoardService bsv;
	private RequestDispatcher rdp;
	private int isOk;
	private String destPage;

	public BoardController() {
		bsv = new BoardServiceImpl();
	}

	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		res.setCharacterEncoding("utf-8");
		res.setContentType("text/html; charset=UTF-8");

		String uri = req.getRequestURI();
		Log.info("uri : " + uri);
		String path = uri.substring(uri.lastIndexOf("/") + 1);
		Log.info("path : " + path);

		switch (path) {
		case "register":
			destPage = "/board/register.jsp";
			break;
		case "insert":
			isOk = bsv.insert(
					new boardVO(req.getParameter("title"), req.getParameter("nick_name"), req.getParameter("content")));
			Log.info("insert " + (isOk > 0 ? "check 4" : "fail 4"));
			destPage = "pagelist";
			break;
		case "list":
			List<boardVO> list = bsv.getList();
			Log.info("list check 1 ");
			req.setAttribute("list", list);
			Log.info("list check 4 ");
			destPage = "/board/list.jsp";
			break;
		case "pagelist":
			try {
				pagingVO pgvo = new pagingVO();
				int totCount = bsv.getPageCnt(); // 전체 카운트 호출
				List<boardVO> list2 = bsv.getListPage(pgvo); // limit이용한 한 페이지 리스트 호출
				PagingHandler ph = new PagingHandler(pgvo, totCount);
				req.setAttribute("list", list2); // 리스트 보내기
				req.setAttribute("pgh", ph); // 페이지 정보 보내기
				destPage = "/board/list.jsp";
			} catch (Exception e) {
				Log.info("paging error");
				e.printStackTrace();
			}
			break;
		case "page":
			try {
				int pageNo = Integer.parseInt(req.getParameter("pageNo"));
				int qty = Integer.parseInt(req.getParameter("qty"));
				System.out.println(pageNo);
				
				pagingVO pgvo = new pagingVO(pageNo, qty);
				
				Log.info("subpage 1");
				int totCount = bsv.getPageCnt(); // 전체 카운트 호출
				List<boardVO> list2 = bsv.getListPage(pgvo); // limit이용한 한 페이지 리스트 호출
				Log.info("subpage 2");
				PagingHandler ph = new PagingHandler(pgvo, totCount);
				req.setAttribute("list", list2); // 리스트 보내기
				req.setAttribute("pgh", ph); // 페이지 정보 보내기
				destPage = "/board/list.jsp";
			} catch (Exception e) {
				Log.info("subpage error");
				e.printStackTrace();
			}
			break;
		case "detail":
			try {
				int bno = Integer.parseInt(req.getParameter("bno"));
				// service에게 호출시 read_count +1하고, 디테일 값을 호출
				bsv.updateCount(bno);
				Log.info("detail check 1");
				boardVO bvo = bsv.getDetail(bno);
				req.setAttribute("bvo", bvo);
				Log.info("detail check 4");
				destPage = "/board/detail.jsp";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "modify":
			try {
				/*
				 * HttpSession ses = req.getSession(); if(String
				 * dfsoifj!=(req.getParameter("writer")){ alert("권한이 없습니다."); destPage="list"; }
				 */
				Log.info("modify check 1");
				boardVO bvo = bsv.getDetail(Integer.parseInt(req.getParameter("bno")));
				req.setAttribute("bvo", bvo);
				Log.info("detail check 4");
				destPage = "/board/modify.jsp";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "update":
			try {
				Log.info("update check 1");
				isOk = bsv.update(new boardVO(Integer.parseInt(req.getParameter("bno")), req.getParameter("title"),
						req.getParameter("content")));
				Log.info("update " + (isOk > 0 ? "check 4" : "fail 4"));
				destPage = "pagelist";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "remove":
			try {
				isOk = bsv.delete(Integer.parseInt(req.getParameter("bno")));
				destPage = "/brd/list";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		}

		rdp = req.getRequestDispatcher(destPage);
		rdp.forward(req, res);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
