/*여기서 입력후 왼쪽 숫자옆에 x표시 뜨는건 무시해도 됨!*/

function printCommentList(bno) {

}
async function postCommentToServer(cmtData) {
	try {
		const url = "/cmt/post";
		const config = {
			method: 'post',
			headers: {
				'Content-Type': 'application/json; charset-utf-8'
			},
			body: JSON.stringify(cmtData)
		};
		const resp = await fetch(url, config);
		const result = await resp.text();
		return result;
	} catch (error) {
		console.log(error);
	}
}

document.getElementById('cmtAddBtn').addEventListener('click',()=>{
	const cmtText = document.getElementById('cmtText').value;
	if(cmtText == null || cmtText==''){
		alert('댓글을 입력해주세요.');
		return false;
	}else{
		let cmtData = {
			bno : bnoVal,
			writer : document.getElementById('cmtWriter').value,
			content : cmtText
		};
		postCommentToServer(cmtData).then(result => {
			if(result>0){
				alert('댓글등록 성공!!');
				document.getElementById('cmtText').value = "";
			}
			printCommentList(cmtData.bno);
		})
	}
})