package service;

import java.util.List;

import domain.boardVO;

public interface boardService {

	int insert(boardVO bvo);

	List<boardVO> getList();

	boardVO getDetail(int bno);

	int update(boardVO bvo);

	int read_countUp(int bno);

	int deleteOne(int bno);

}
