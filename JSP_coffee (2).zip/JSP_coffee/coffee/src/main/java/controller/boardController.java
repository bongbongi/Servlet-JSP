package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.boardVO;
import domain.memberVO;
import service.boardService;
import service.boardServiceImpl;


@WebServlet("/brd/*")
public class boardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Logger Log = LoggerFactory.getLogger("boardController.class");  
    private String destPage;
    private int isOk;
    private boardService bsv;
    private RequestDispatcher rdp;
  
    public boardController() {
    	bsv = new boardServiceImpl();
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String uri = request.getRequestURI();
		String path = uri.substring(uri.lastIndexOf("/")+1);
		Log.info("uri >>> "+uri);
		Log.info("path >>> "+path);
		
		switch(path) {
		case "list":
			HttpSession ses = request.getSession();
			List<boardVO> list =  bsv.getList(); ;
			request.setAttribute("list", list);
			destPage="/board/list.jsp";
			break;
		case "register":
			destPage="/board/register.jsp";
			break;
		case "insert":
			try {
				isOk = bsv.insert(new boardVO(
						/* Integer.parseInt(request.getParameter("bno")), */
							request.getParameter("title"),
							request.getParameter("writer"),
							request.getParameter("content"),
							request.getParameter("image_file")));
				Log.info("글작성 >>> "+(isOk>0?"성공":"실패"));
			} catch (Exception e) {
				e.printStackTrace();
			}
			destPage="/brd/list";
			break;
		case "detail":
			try {
				//클릭하면 해당하는 bno의 read_count 올리기
				isOk = bsv.read_countUp(Integer.parseInt(request.getParameter("bno")));
				
				boardVO bvo = bsv.getDetail(Integer.parseInt(request.getParameter("bno")));
				request.setAttribute("bvo", bvo);
			} catch (Exception e) {
				e.printStackTrace();
			}
			destPage="/board/detail.jsp";
			break;
		case "modify":
			boardVO bvo = bsv.getDetail(Integer.parseInt(request.getParameter("bno")));
			request.setAttribute("bvo", bvo);
			destPage="/board/modify.jsp";
			break;
		case "update":
			try {
				isOk = bsv.update(new boardVO(
						Integer.parseInt(request.getParameter("bno")),
						request.getParameter("title"),
						request.getParameter("content"),
						request.getParameter("image_file")
						));
				Log.info("내정보 수정 "+(isOk>0?"Ok":"Fail"));
				destPage="/brd/list";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "remove":
			isOk = bsv.deleteOne(Integer.parseInt(request.getParameter("bno")));
			destPage="/brd/list";
			break;
		}
		rdp = request.getRequestDispatcher(destPage);
		rdp.forward(request, response);
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
