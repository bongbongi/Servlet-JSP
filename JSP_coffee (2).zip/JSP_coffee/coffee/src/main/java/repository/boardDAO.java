package repository;

import java.util.List;

import domain.boardVO;

public interface boardDAO {

	int insertOne(boardVO bvo);

	List<boardVO> getList();

	boardVO getDetail(int bno);

	int update(boardVO bvo);

	int read_countUp(int bno);

	int delete(int bno);

}
