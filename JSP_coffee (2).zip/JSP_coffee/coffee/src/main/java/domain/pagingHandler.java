package domain;

public class pagingHandler {
	//시작페이지, 끝페이지, 이전다음
	private int startPage;
	private int endPage;
	private boolean prev, next;
	
	//전체글수, pagingVO
	private int totalPage;
	private pagingVO pvo;
	private int realEndPage;
	
	public pagingHandler() {}
	public pagingHandler(pagingVO pvo, int totalPage) {
		this.pvo=pvo;
		this.totalPage=totalPage;
		
		this.endPage=(int)Math.ceil(pvo.getPageNo()/(pvo.getQty()*1.0)) * pvo.getQty();
	}
}
