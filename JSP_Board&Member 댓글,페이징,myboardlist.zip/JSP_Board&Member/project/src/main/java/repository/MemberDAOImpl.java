package repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.memberVO;
import orm.DatabaseBuilder;
import service.MemberServiceImpl;

public class MemberDAOImpl implements MemberDAO {
	private static final Logger Log = LoggerFactory.getLogger(MemberDAOImpl.class);
	private SqlSession sql;
	private final String NS = "memberMapper.";
	
	public MemberDAOImpl() {
		new DatabaseBuilder();
		sql = DatabaseBuilder.getFactory().openSession();
	}

	@Override
	public memberVO selectOne(memberVO mvo) {
		Log.info("login check 3");
		return sql.selectOne(NS+"login",mvo);
	}

	@Override
	public int insert(memberVO mvo) {
		Log.info("insert check 3");
		int isOk = sql.insert(NS+"reg",mvo);
		if(isOk>0) {
			sql.commit();
		}
		return isOk;
	}

	@Override
	public int update(String email) {
		Log.info("lastLogin check 3");
		int isOk = sql.update(NS+"last",email);
		if(isOk>0) {
			sql.commit();
		}
		return isOk;
	}

	@Override
	public List<memberVO> list() {
		Log.info("list check 3");
		return sql.selectList(NS+"list");
	}


	@Override
	public memberVO getDetail(String email) {
		Log.info("detail check 3");
		return sql.selectOne(NS+"detail",email);
	}

	@Override
	public int updateOne(memberVO mvo) {
		Log.info("update check 3");
		int isOk= sql.update(NS+"update",mvo);
		if(isOk>0) {
			sql.commit();
		}
		return isOk;
	}

	@Override
	public int remove(String email) {
		Log.info("remove check 3");
		int isOk= sql.delete(NS+"remove",email);
		if(isOk>0) {
			sql.commit();
		}
		return isOk;
	}


	
	
}
