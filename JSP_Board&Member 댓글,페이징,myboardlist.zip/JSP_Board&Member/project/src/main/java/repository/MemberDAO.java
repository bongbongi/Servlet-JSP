package repository;

import java.util.List;

import domain.memberVO;

public interface MemberDAO {

	memberVO selectOne(memberVO mvo);

	int insert(memberVO mvo);

	int update(String email);

	List<memberVO> list();

	memberVO getDetail(String email);

	int updateOne(memberVO mvo);

	int remove(String email);

}
