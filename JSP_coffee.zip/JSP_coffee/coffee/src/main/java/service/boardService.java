package service;

import domain.boardVO;

public interface boardService {

	int insert(boardVO bvo);

}
