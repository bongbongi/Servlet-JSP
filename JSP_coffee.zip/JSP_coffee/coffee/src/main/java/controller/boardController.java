package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.boardVO;
import service.boardService;
import service.boardServiceImpl;


@WebServlet("/brd/*")
public class boardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Logger Log = LoggerFactory.getLogger("boardController.class");  
    private String destPage;
    private int isOk;
    private boardService bsv;
    private RequestDispatcher rdp;
  
    public boardController() {
    	bsv = new boardServiceImpl();
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String uri = request.getRequestURI();
		String path = uri.substring(uri.lastIndexOf("/")+1);
		Log.info("uri >>> "+uri);
		Log.info("path >>> "+path);
		
		switch(path) {
		case "list":
			HttpSession ses = request.getSession();
			destPage="/board/list.jsp";
			break;
		case "register":
			destPage="/board/register.jsp";
			break;
		case "insert":
			try {
				isOk = bsv.insert(new boardVO(
							Integer.parseInt(request.getParameter("bno")),
							request.getParameter("title"),
							request.getParameter("writer"),
							request.getParameter("content"),
							request.getParameter("image_file")));
				Log.info("글작성 >>> "+(isOk>0?"성공":"실패"));
			} catch (Exception e) {
				e.printStackTrace();
			}
			destPage="list";
			break;
		case "detail":
			break;
		case "modify":
			break;
		case "remove":
			break;
		}
		rdp = request.getRequestDispatcher(destPage);
		rdp.forward(request, response);
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
