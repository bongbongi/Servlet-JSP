package repository;

import domain.boardVO;

public interface boardDAO {

	int insertOne(boardVO bvo);

}
