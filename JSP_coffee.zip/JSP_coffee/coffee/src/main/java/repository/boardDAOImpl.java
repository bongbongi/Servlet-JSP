package repository;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.boardVO;
import orm.DatabaseBuilder;

public class boardDAOImpl implements boardDAO {
	private Logger Log = LoggerFactory.getLogger("boardDAOImpl");
	private SqlSession sql;
	private int isOk;
	private final String NS = "boardMapper.";
	
	public boardDAOImpl() {
		new DatabaseBuilder();
		sql = DatabaseBuilder.getFactory().openSession();
	}

	@Override
	public int insertOne(boardVO bvo) {
		Log.info("글작성 체크2");
		isOk = sql.insert(NS+"insert",bvo);
		if(isOk>0) {
			sql.commit();
		}
		return isOk;
	}
			
		
}

