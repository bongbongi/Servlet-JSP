package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.memberVO;
import service.MemberService;
import service.MemberServiceImpl;

@WebServlet("/mem/*")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// destpage, service인터페이스, Logger, isOk, RequestDispatcher
	private static final Logger Log = LoggerFactory.getLogger(MemberController.class);
	private MemberService msv;
	private RequestDispatcher rdp;
	private int isOk;
	private String destPage;

	public MemberController() {
		msv = new MemberServiceImpl();
	}

	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		res.setCharacterEncoding("utf-8");
		res.setContentType("text/html; charset=UTF-8");

		String uri = req.getRequestURI();
		Log.info("uri : " + uri);
		String path = uri.substring(uri.lastIndexOf("/") + 1);
		Log.info("path : " + path);

		switch (path) {
		case "login": // 로그인 페이지 이동
			destPage = "/member/login.jsp";
			break;
		case "login_auth": // 실제 로그인이 일어나는 케이스
			try {
				Log.info("login check 1");
				memberVO mvo = msv.login(new memberVO(req.getParameter("email"), req.getParameter("pwd")));
				Log.info("login check 4");
				if (mvo != null) {
					// 연결된 세션이 없다면 새로 생성, 있다면 그 세션 가져오기
					HttpSession ses = req.getSession();
					// ses로 mvo를 바인딩
					ses.setAttribute("ses", mvo);
					ses.setMaxInactiveInterval(10 * 60); // 로그인 유지시간 (10분설정)
				} else {
					// 로그인 못했다면
					// 0은 아무의미 없음. 본인마음
					req.setAttribute("msg_login", 0);
				}
				destPage = "/";

			} catch (Exception e) {
				e.printStackTrace();
			}

			break;
		case "join": // 회원가입 페이지 이동
			destPage = "/member/join.jsp";
			break;
		case "register": // 회원가입 DB저장
			isOk = msv.register(
					new memberVO(req.getParameter("email"), req.getParameter("pwd"), req.getParameter("nick_name")));
			Log.info("register " + (isOk > 0 ? "check" : "fail"));
			destPage = "/member/login.jsp";
			break;
		case "logout":
			try {
				// 연결된 세션이 있다면 해당 세션을 가져오기
				HttpSession ses = req.getSession();
				memberVO mvo = (memberVO) ses.getAttribute("ses");
				String email = mvo.getEmail();
				Log.info(email);
				ses.invalidate(); // 세션 끊기
				// 로그인된 이메일을 주고 로그인 시간 update
//				isOk = msv.lastLogin(req.getParameter("email"));
				isOk = msv.lastLogin(email);
				Log.info("lastLogin " + (isOk > 0 ? "check 4 " : "fail 4"));
				destPage = "/";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "list":
			List<memberVO> list = msv.getList();
			Log.info("list check 1 ");
			req.setAttribute("list", list);
			Log.info("list check 4 ");
			destPage = "/member/list.jsp";
			break;
		case "detail": // 기존 정보 가져오고, 수정
			try {
				String email = req.getParameter("email");
				Log.info("detail check 1 ");
				memberVO mvo = msv.getDetail(email);
				req.setAttribute("mvo", mvo);
				Log.info("detail check 4 ");
				destPage = "/member/modify.jsp";
			} catch (Exception e) {
				e.printStackTrace();
			}
		case "update":
			try {
				Log.info("update check 1");
				isOk = msv.update(new memberVO(req.getParameter("email"), req.getParameter("pwd"),
						req.getParameter("nick_name")));
				Log.info("update " + (isOk > 0 ? "check 4" : "fail 4"));
				destPage = "/";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "remove":
			try {
				msv.remove(req.getParameter("email"));
				destPage = "/";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}

		rdp = req.getRequestDispatcher(destPage);
		rdp.forward(req, res);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
