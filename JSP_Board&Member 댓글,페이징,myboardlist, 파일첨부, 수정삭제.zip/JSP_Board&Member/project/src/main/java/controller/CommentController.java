package controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.CommentVO;
import service.CommentService;
import service.CommentServiceImpl;

@WebServlet("/cmt/*")
public class CommentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger Log = LoggerFactory.getLogger(CommentController.class);
	private CommentService csv;
	private int isOk;
	private String destPage;

	public CommentController() {
		csv = new CommentServiceImpl();
	}

	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		res.setCharacterEncoding("utf-8");

		String uri = req.getRequestURI(); // 'cmt/list/10' -> list와 10을 각각 가져오기 , /cmt/post. /cmt/modify
		String pathUri = uri.substring("/cmt/".length());
		String path = pathUri;
		String pathVar = null;
		if (pathUri.contains("/")) {
			path = pathUri.substring(0, pathUri.lastIndexOf("/")); // list
			pathVar = pathUri.substring(pathUri.lastIndexOf("/") + 1); // 10
		}
		Log.info(">>> uri >> " + uri);
		Log.info(">>> path >> " + path);
		Log.info(">>> pathUri >> " + pathUri);

		switch (path) {
		case "post":
			try {
				// js에서 보낸 데이터를 StringBuffer로 읽어들이는 작업
				// json형태이기때문에 getparameter로 가져올 수 없음
				StringBuffer sb = new StringBuffer();
				String line = null;
				BufferedReader br = req.getReader();// 댓글 객체
				while ((line = br.readLine()) != null) {// 값이 null아니라면(남아있다면)
					sb.append(line);
				}
				// sb는 객체인척 하는 가짜객체
				Log.info(">>> sb : " + sb.toString());
				// JsonParser은 진짜 객체로 만들어줌
				// 객체로 생성, JSONParser는 simple로 import하기
				JSONParser parser = new JSONParser();
				JSONObject jsonObj = (JSONObject) parser.parse(sb.toString()); // key=value

				// object 객체로 가져오기때문에 toString으로 가져와야함..
				int bno = Integer.parseInt(jsonObj.get("bno").toString());
				String writer = jsonObj.get("writer").toString();
				String content = jsonObj.get("content").toString();
				isOk = csv.post(new CommentVO(bno, writer, content));
				Log.info("post " + (isOk > 0 ? "OK" : "FAIL"));
				// 화면에 출력
				PrintWriter out = res.getWriter();
				// println 아님! 값을 읽을수 없으므로 주의하기
				out.print(isOk);
			} catch (Exception e) {
				Log.info(">>> Comment > post > error");
				e.printStackTrace();
			}
			break;
		case "list":
			try {
				List<CommentVO> list = csv.getList(Integer.parseInt(pathVar));
				Log.info(">>> comment > list > DB성공");
				// json 형태로 변환
				JSONObject[] jsonObjArr = new JSONObject[list.size()];
				JSONArray jsonObjList = new JSONArray();
				for (int i = 0; i < list.size(); i++) {
					jsonObjArr[i] = new JSONObject(); // JSONObject는 key:value 형태
					jsonObjArr[i].put("cno", list.get(i).getCno());
					jsonObjArr[i].put("bno", list.get(i).getBno());
					jsonObjArr[i].put("writer", list.get(i).getWriter());
					jsonObjArr[i].put("content", list.get(i).getContent());
					jsonObjArr[i].put("reg_at", list.get(i).getReg_at());

					jsonObjList.add(jsonObjArr[i]);// 객체 리스트 추가
				}
				String jsonData = jsonObjList.toJSONString();

				PrintWriter out = res.getWriter();
				out.print(jsonData);
			} catch (Exception e) {
				Log.info(">>> comment > list > error");
				e.printStackTrace();
			}
			break;
		case "modify":
			try {
				// js에서 보낸 데이터를 StringBuffer로 읽어들이는 작업
				// json형태이기때문에 getparameter로 가져올 수 없음
				StringBuffer sb = new StringBuffer();
				String line = null;
				BufferedReader br = req.getReader();// 댓글 객체
				while ((line = br.readLine()) != null) {// 값이 null아니라면(남아있다면)
					sb.append(line);
				}
				// sb는 객체인척 하는 가짜객체
				Log.info(">>> sb : " + sb.toString());
				// JsonParser은 진짜 객체로 만들어줌
				// 객체로 생성, JSONParser는 simple로 import하기
				JSONParser parser = new JSONParser();
				JSONObject jsonObj = (JSONObject) parser.parse(sb.toString()); // key=value

				// object 객체로 가져오기때문에 toString으로 가져와야함..
				int cno = Integer.parseInt(jsonObj.get("cno").toString());
				String content = jsonObj.get("content").toString();
				isOk = csv.update(new CommentVO(cno, content));
				Log.info("post " + (isOk > 0 ? "OK" : "FAIL"));
				// 화면에 출력
				PrintWriter out = res.getWriter();
				// println 아님! 값을 읽을수 없으므로 주의하기
				out.print(isOk);
			} catch (Exception e) {
				Log.info(">>> comment > modify > error");
				e.printStackTrace();
			}
			break;
		case "remove":
			try {
				isOk = csv.getDelete(Integer.parseInt(pathVar));
				Log.info("remove " + (isOk > 0 ? "OK" : "FAIL"));

				PrintWriter out = res.getWriter();
				out.print(isOk);
			} catch (Exception e) {
				Log.info(">>> comment > remove > error");
				e.printStackTrace();
			}
			break;
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}