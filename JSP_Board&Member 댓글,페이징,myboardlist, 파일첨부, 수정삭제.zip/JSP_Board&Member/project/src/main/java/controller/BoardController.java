package controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane.SystemMenuBar;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.boardVO;
import domain.memberVO;
import domain.pagingVO;
import handler.FileHandler;
import handler.PagingHandler;
import net.coobird.thumbnailator.Thumbnails;
import service.BoardService;
import service.BoardServiceImpl;
import service.MemberService;

@WebServlet("/brd/*")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger Log = LoggerFactory.getLogger(MemberController.class);
	private BoardService bsv;
	private RequestDispatcher rdp;
	private int isOk;
	private String destPage;
	private String savePath; // 파일 경로를 저장할 변수
	private final String UTF8 = "utf-8"; // 인코딩 설정시 필요함

	public BoardController() {
		bsv = new BoardServiceImpl();
	}

	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		res.setCharacterEncoding("utf-8");
		res.setContentType("text/html; charset=UTF-8");

		String uri = req.getRequestURI();
		Log.info("uri : " + uri);
		String path = uri.substring(uri.lastIndexOf("/") + 1);
		Log.info("path : " + path);

		switch (path) {
		case "register":
			destPage = "/board/register.jsp";
			break;
		case "insert":
			/*
			 * isOk = bsv.insert( new boardVO(req.getParameter("title"),
			 * req.getParameter("email"), req.getParameter("content"))); Log.info("insert "
			 * + (isOk > 0 ? "check 4" : "fail 4")); destPage = "pagelist";
			 */
			try {
				// 파일을 업로드할 물리적인 경로 설정(업로드 할 때 설정)
				savePath = getServletContext().getRealPath("/_fileUpLoad"); // 실제경로
				// File은 java io로 import하기
				File fileDir = new File(savePath);
				Log.info("저장 위치: " + savePath);

				// 업로드 된 파일을 저장할 저장소와 관련된 클래스
				DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
				fileItemFactory.setRepository(fileDir); // 저장할 위치를 file 객체로 지정
				fileItemFactory.setSizeThreshold(2 * 1024 * 1024); // 저장을 위한 임시 메모리 저장 용량 설정 : byte 단위

				boardVO bvo = new boardVO();
				// jsp에서 온 multipart/form-data 형식으로 넘어온 request 객체를 다루기 쉽게 변환해주는 역할
				ServletFileUpload fileUpload = new ServletFileUpload(fileItemFactory);

				// FileItem은 commons로 import
				List<FileItem> itemList = fileUpload.parseRequest(req);
				for (FileItem item : itemList) {
					// input의 name에 해당하는 값
					switch (item.getFieldName()) {
					case "title":
						bvo.setTitle(item.getString(UTF8));// 인코딩 형식을 담아서 변환
						break;
					case "email":
						bvo.setWriter(item.getString(UTF8));
						Log.info(bvo.getWriter());
						break;
					case "content":
						bvo.setContent(item.getString(UTF8));
						break;
					case "image_file":
						// 이미지가 있는지 없는지 체크
						if (item.getSize() > 0) { // 데이터의 코기를 바이트 단위로 리턴
							// String fileName = item.getName(); //경로가 포함된 전체 이름이 출력
							String fileName = item.getName().substring(item.getName().lastIndexOf("/") + 1); // 파일 이름만
																												// 분리
							fileName = System.currentTimeMillis() + "_" + fileName;// 현재 시스템 시간_dog.jsp
							File UploadFilePath = new File(fileDir + File.separator + fileName);
							Log.info("파일 경로 + 이름 : " + UploadFilePath);
							// 저장
							try {
								item.write(UploadFilePath); // 자바 객체를 디스크에 쓰기
								bvo.setImage_file(fileName);

								// 썸네일 작업 : 리스트 페이지에서 트래픽 과다사용 방지
								Thumbnails.of(UploadFilePath).size(75, 75)
										.toFile(new File(fileDir + File.separator + "th_" + fileName));
							} catch (Exception e) {
								Log.info(">>> file writer on disk fail");
								e.printStackTrace();
							}
						}
						break;
					}
				}
				isOk = bsv.insert(bvo);
				Log.info(">>> insert > " + (isOk > 0 ? "OK" : "Fail"));
				destPage = "pagelist";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "list":
			try {
				HttpSession ses = req.getSession();
				memberVO mvo = (memberVO) ses.getAttribute("ses");
				Log.info("myList check1");
				String email = mvo.getEmail();
				/* String email = req.getParameter("email"); */
				System.out.println(email);
				List<boardVO> list = bsv.getMyList(email);
				System.out.println(list.get(0).getWriter());
				req.setAttribute("list1", list);
				Log.info("myList check4");
				destPage = "/board/myList.jsp";
			} catch (Exception e) {
				Log.info("MyList error");
				e.printStackTrace();
			}
			break;
		case "pagelist":
			try {
				pagingVO pgvo = new pagingVO();
				int totCount = bsv.getPageCnt(); // 전체 카운트 호출
				List<boardVO> list2 = bsv.getListPage(pgvo); // limit이용한 한 페이지 리스트 호출
				PagingHandler ph = new PagingHandler(pgvo, totCount);
				req.setAttribute("list", list2); // 리스트 보내기
				req.setAttribute("pgh", ph); // 페이지 정보 보내기
				destPage = "/board/list.jsp";
			} catch (Exception e) {
				Log.info("paging error");
				e.printStackTrace();
			}
			break;
		case "page":
			try {
				int pageNo = Integer.parseInt(req.getParameter("pageNo"));
				int qty = Integer.parseInt(req.getParameter("qty"));
				System.out.println(pageNo);

				pagingVO pgvo = new pagingVO(pageNo, qty);

				Log.info("subpage 1");
				int totCount = bsv.getPageCnt(); // 전체 카운트 호출
				List<boardVO> list2 = bsv.getListPage(pgvo); // limit이용한 한 페이지 리스트 호출
				Log.info("subpage 2");
				PagingHandler ph = new PagingHandler(pgvo, totCount);
				req.setAttribute("list", list2); // 리스트 보내기
				req.setAttribute("pgh", ph); // 페이지 정보 보내기
				destPage = "/board/list.jsp";
			} catch (Exception e) {
				Log.info("subpage error");
				e.printStackTrace();
			}
			break;
		case "detail":
			try {
				int bno = Integer.parseInt(req.getParameter("bno"));
				// service에게 호출시 read_count +1하고, 디테일 값을 호출
				bsv.updateCount(bno);
				Log.info("detail check 1");
				boardVO bvo = bsv.getDetail(bno);
				req.setAttribute("bvo", bvo);
				Log.info("detail check 4");
				destPage = "/board/detail.jsp";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "modify":
			try {
				/*
				 * HttpSession ses = req.getSession(); if(String
				 * dfsoifj!=(req.getParameter("writer")){ alert("권한이 없습니다."); destPage="list"; }
				 */
				Log.info("modify check 1");
				boardVO bvo = bsv.getDetail(Integer.parseInt(req.getParameter("bno")));
				req.setAttribute("bvo", bvo);
				Log.info("detail check 4");
				destPage = "/board/modify.jsp";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "update":
			try {
				savePath = getServletContext().getRealPath("/_fileUpLoad");
				File fileDir = new File(savePath);

				DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
				fileItemFactory.setRepository(fileDir);
				fileItemFactory.setSizeThreshold(2 * 1024 * 1024);

				boardVO bvo = new boardVO();

				ServletFileUpload fileUpload = new ServletFileUpload(fileItemFactory);
				Log.info(">> update 준비 >>");

				List<FileItem> itemList = fileUpload.parseRequest(req);

				String old_file = null;
				for (FileItem item : itemList) {
					switch (item.getFieldName()) {
					case "bno":
						bvo.setBno(Integer.parseInt(item.getString(UTF8)));
						
						System.out.println(bvo.getBno());
						break;
					case "title":
						bvo.setTitle(item.getString(UTF8));
						break;
					case "content":
						bvo.setContent(item.getString(UTF8));
						break;
					case "image_file": // 기존 파일
						// new_file이 들어오지 않았다면 기존파일 유지해야함.
						// 항상 delete가 되는거 아님!! 파일외에 다른 부분만 수정할 수 있기 때문.
						old_file = item.getString(UTF8);
						break;
					case "new_file": // 새 파일
						if (item.getSize() > 0) { // 새로운 파일이 등록 됨.
							if (old_file != null) {
								// 기존 파일이 있는 상태에서 새로운 파일이 생겼다면 삭제 할 수 있음
								// 파일 핸들러 작업(기존 파일을 삭제)
								FileHandler fileHandler = new FileHandler();
								isOk = fileHandler.deleteFile(old_file, savePath);
							}
							// 경로가 포함된 전체 경로와 파일이름 생성
							// 실제 파일 이름 추출
							String fileName = item.getName().substring(item.getName().lastIndexOf("/") + 1);
							Log.info("newfileName : " + fileName);
							// 실제 저장될 파일 이름
							fileName = System.currentTimeMillis() + "_" + fileName;
							// 업로드 되어야 하는 실제 파일 경로
							File uploadFilePath = new File(fileDir + File.separator + fileName);
							try {
								item.write(uploadFilePath); // 자바 객체를 디스크에 쓰기
								bvo.setImage_file(fileName);
								Log.info(">> upload img_file : " + (bvo.getImage_file()));
								
								//썸네일 작업
								Thumbnails.of(uploadFilePath).size(75, 75)
										.toFile(new File(fileDir + File.separator + "th_" + fileName));
							} catch (Exception e) {
								Log.info(">>> File Write on disk Fail");
								e.printStackTrace();
							}
						}else {
							//새로운 파일이 없다면 기존파일을 bvo 객체에 담기
							bvo.setImage_file(old_file);
						}
						break;
					}
				}
				isOk = bsv.update(bvo);
				Log.info(">> update >"+(isOk>0?"OK":"FAil"));
				destPage = "pagelist";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "remove":
			try {
				int bno = Integer.parseInt(req.getParameter("bno"));
				// image_file name 불러오기
				// db삭제전에 파일 가져오기
				String imageFileName = bsv.getFileName(bno);// 삭제할 파일 이름 호출
				FileHandler fileHandler = new FileHandler();
				savePath = getServletContext().getRealPath("/_fileUpLoad");
				isOk = fileHandler.deleteFile(imageFileName, savePath);
				Log.info("fileDelete >> " + (isOk > 0 ? "OK" : "Fail"));
				isOk = bsv.delete(bno);
				Log.info("allDelete >> " + (isOk > 0 ? "OK" : "Fail"));
				destPage = "pagelist";
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
		rdp = req.getRequestDispatcher(destPage);
		rdp.forward(req, res);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
