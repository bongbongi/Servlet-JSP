package handler;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileHandler {
	private static Logger Log = LoggerFactory.getLogger(FileHandler.class);
	
	//파일 이름과 경로를 받아서 파일을 삭제하는 메서드
	//리턴 타입이 int인 경우는 잘 삭제되었는지 체크하기 위한 변수
	public int deleteFile(String imageFileName, String savePath) {
		boolean isDel =  true; //삭제가 잘 이루어졌는지 체크하는 변수
		Log.info(">>> deleteFile method 접근");
		Log.info(">>> imageFileName"+imageFileName);
		
		//파일경로
		File fileDir = new File(savePath);
		File removeFile = new File(fileDir+File.separator+imageFileName);
		File removeThumFile = new File(fileDir+File.separator+"th_"+imageFileName);

		//파일 존재 여부 확인 ->있어야 삭제 가능
		if(removeFile.exists() || removeThumFile.exists()) {
			isDel = removeFile.delete(); // boolean형태로 삭제가 되었으면 true
			Log.info(">>> FileHandler remove : "+(isDel?"OK":"Fail"));
			if(isDel) { //잘 지워졌다면
				isDel = removeThumFile.delete(); //원본 삭제후 썸네일 삭제
				Log.info(">>> FileHandler remove Thumbnail : "+(isDel?"OK":"Fail"));
			}
		}		
		Log.info(">> FileHandler remove OK");
		return isDel?1:0;  //true면 1, 아니면 0
	}
}
