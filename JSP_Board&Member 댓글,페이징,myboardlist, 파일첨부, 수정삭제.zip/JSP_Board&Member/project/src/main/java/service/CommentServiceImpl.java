package service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.CommentController;
import domain.CommentVO;
import repository.CommentDAO;
import repository.CommentDAOImpl;

public class CommentServiceImpl implements CommentService {
	private static Logger Log = LoggerFactory.getLogger(CommentController.class);
	private CommentDAO cdao;
	//생성자
	public CommentServiceImpl() {
		cdao = new CommentDAOImpl();
	}
	@Override
	public int post(CommentVO cvo) {
		Log.info(">>> comment > post > check2");
		return cdao.insert(cvo);
	}
	@Override
	public List<CommentVO> getList(int bno) {
		Log.info(">>> comment > list > check2");
		return cdao.selectList(bno);
	}
	@Override
	public int getDelete(int cno) {
		Log.info(">>> comment > remove > check2");
		return cdao.delete(cno);
	}
	@Override
	public int update(CommentVO cvo) {
		Log.info(">>> comment > modify > check2");
		return cdao.update(cvo);
	}
	public int removeAll(int bno) {
		// TODO Auto-generated method stub
		return cdao.removeAll(bno);
	}
	
	
}
