package repository;

import java.util.List;

import domain.boardVO;
import domain.pagingVO;

public interface BoardDAO {

	int insert(boardVO bvo);

	List<boardVO> list();

	boardVO detail(int bno);

	int update(boardVO bvo);

	int delete(int bno);

	int updateCount(int bno);

	int selectCount();

	List<boardVO> selectList(pagingVO pgvo);

	List<boardVO> getMyList(String email);



}
