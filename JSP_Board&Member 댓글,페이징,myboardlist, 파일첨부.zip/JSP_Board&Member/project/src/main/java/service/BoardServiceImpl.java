package service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import domain.boardVO;
import domain.pagingVO;
import repository.BoardDAO;
import repository.BoardDAOImpl;


public class BoardServiceImpl implements BoardService {
	private static final Logger Log = LoggerFactory.getLogger(MemberServiceImpl.class);
	private BoardDAO bdao;
	
	public BoardServiceImpl() {
		bdao = new BoardDAOImpl();
	}

	@Override
	public int insert(boardVO bvo) {
		Log.info("insert check 2");
		return bdao.insert(bvo);
	}

	@Override
	public List<boardVO> getList() {
		Log.info("list check 2");
		
		return bdao.list();
	}

	@Override
	public boardVO getDetail(int bno) {
		Log.info("detail check 2");
		return bdao.detail(bno);
	}

	@Override
	public int update(boardVO bvo) {
		Log.info("update check 2");
		return bdao.update(bvo);
	}

	@Override
	public int delete(int bno) {
		Log.info("delete check 2");
		return bdao.delete(bno);
	}

	@Override
	public int updateCount(int bno) {
		Log.info("updateCount check 2");
		return bdao.updateCount(bno);
	}

	@Override
	public int getPageCnt() {
		Log.info("pageCnt check 2");
		return bdao.selectCount();
	}

	@Override
	public List<boardVO> getListPage(pagingVO pgvo) {
		return bdao.selectList(pgvo);
	}

	@Override
	public List<boardVO> getMyList(String email) {
		Log.info("myList check2");
		return bdao.getMyList(email);
	}
	
	
}
