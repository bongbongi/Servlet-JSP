package service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.MemberController;
import domain.memberVO;
import repository.MemberDAO;
import repository.MemberDAOImpl;

public class MemberServiceImpl implements MemberService {
	private static final Logger Log = LoggerFactory.getLogger(MemberServiceImpl.class);
	private MemberDAO mdao;
	
	public MemberServiceImpl() {
		mdao = new MemberDAOImpl();
	}

	@Override
	public memberVO login(memberVO mvo) {
		Log.info("login check 2");
		return mdao.selectOne(mvo);
	}

	@Override
	public int register(memberVO mvo) {
		Log.info("register check 2");
		return mdao.insert(mvo);
	}

	@Override
	public int lastLogin(String email) {
		Log.info("lastLogin check 2");
		return mdao.update(email);
	}

	@Override
	public List<memberVO> getList() {
		Log.info("list check 2");
		return mdao.list();
	}


	@Override
	public memberVO getDetail(String email) {
		Log.info("detail check 2");
		
		
		return mdao.getDetail(email);
	}

	@Override
	public int update(memberVO mvo) {
		Log.info("update check 2");
		return mdao.updateOne(mvo);
	}

	@Override
	public int remove(String email) {
		Log.info("remove check 2");
		return mdao.remove(email);
	}
	
	
	
}
